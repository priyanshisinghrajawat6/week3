# Week 3 Assignment: Data Visualization & EDA

**Name:** ____________________  **Date:** ____________
**Internship:** Data Science, Next Gen Software Hub Pvt. Ltd.
**Instructions:** Sabhi questions ko apne notebook mein Python (Pandas, Matplotlib, Seaborn) se solve karein. Har plot par title aur axis labels zaroor lagayein. Har section ke baad 2-3 line mein apna observation likhein.

---

## Part A: Theory (short answers)
1. EDA kya hota hai aur data science project mein ye zaroori kyun hai?
2. Univariate, bivariate aur multivariate analysis mein difference batayein (ek-ek example ke saath).
3. Histogram aur bar plot mein kya difference hai?
4. Box plot ke 5 numbers (five-number summary) kaun se hain? Outlier kaise identify hota hai?
5. Missing values handle karne ke 3 tareeke likhein. Kab mean, kab median aur kab mode use karna chahiye?
6. Correlation ki value +0.9, 0 aur -0.8 ka matlab samjhayein. Kya correlation ka matlab causation hota hai?

## Part B: Practical (Dataset: notebook wala retail sales dataset)
**Q1. Data understanding**
a) Dataset ka shape, data types aur summary statistics print karein.
b) Har column ke missing values aur duplicate rows count karein.

**Q2. Data cleaning**
a) Duplicates hatayein.
b) `region` ke missing values mode se aur `unit_price` ke median se fill karein.
c) `order_date` se `quarter` aur `is_weekend` naye columns banayein.

**Q3. Univariate analysis**
a) `sales` aur `profit` ke histogram (KDE ke saath) banayein. Distribution skewed hai ya symmetric?
b) `segment` ka count plot aur pie chart banayein.

**Q4. Outliers**
a) `profit` column mein IQR method se outliers dhoondhein.
b) Outliers ko cap karein aur before/after box plot compare karein.

**Q5. Bivariate analysis**
a) Har `category` ka average sales aur total profit bar plot mein dikhayein.
b) `quantity` vs `sales` ka scatter plot banayein aur relation likhein.
c) Region-wise sales ka box plot banayein. Kaunsa region sabse consistent hai?

**Q6. Time analysis**
a) Monthly sales ka line plot banayein.
b) Weekday-wise average sales ka bar plot banayein. Kaunsa din sabse best hai?

**Q7. Multivariate analysis**
a) Numerical columns ka correlation heatmap banayein.
b) `region x segment` ka pivot table (total profit) banayein aur heatmap mein dikhayein.
c) `pairplot` banayein (`hue="category"`).

**Q8. Dashboard**
2x2 subplot dashboard banayein jisme 4 alag-alag type ke charts hon.

**Q9. Insights**
Apne analysis se kam se kam **5 business insights** likhein aur 2 recommendations dein (jaise discount policy, best category par focus).

## Part C: Bonus (optional)
- Apna khud ka CSV dataset (Kaggle / data.gov.in) lekar poora EDA karein.
- `plotly` se ek interactive chart banayein.

## Submission
- Notebook: `Week3_Assignment_<YourName>.ipynb`
- GitHub repository mein upload karke link share karein.

## Marking scheme
| Section | Marks |
|---|---|
| Part A: Theory | 20 |
| Q1-Q2: Understanding and cleaning | 15 |
| Q3-Q4: Univariate and outliers | 15 |
| Q5-Q7: Bivariate and multivariate | 25 |
| Q8: Dashboard | 10 |
| Q9: Insights | 15 |
| **Total** | **100** |
