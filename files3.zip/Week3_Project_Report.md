# Week 3 Project Report
## Data Visualization & Exploratory Data Analysis (EDA)

**Internship:** Data Science, Next Gen Software Hub Pvt. Ltd.
**Week:** 3 of 6
**Name:** ____________________

---

## 1. Introduction
Is hafte ka focus data ko samajhna aur visualize karna tha. Kisi bhi machine learning model se pehle EDA zaroori hota hai kyunki isse data ki quality, patterns, outliers aur relationships ka pata chalta hai. Week 1 mein Python basics aur Week 2 mein Pandas & NumPy seekhne ke baad, is week Matplotlib aur Seaborn se EDA kiya gaya.

## 2. Objectives
- Raw data ko clean karna (duplicates, missing values, outliers).
- Univariate, bivariate aur multivariate analysis karna.
- Visualizations se insights nikalna aur unhe clearly present karna.

## 3. Tools and Technologies
| Tool | Use |
|---|---|
| Python 3 | Programming language |
| Pandas, NumPy | Data handling and calculations |
| Matplotlib | Basic plotting |
| Seaborn | Statistical visualizations |
| Jupyter Notebook | Code + documentation |

## 4. Dataset Description
Ek retail sales dataset (500 orders) use kiya gaya jisme ye columns hain: `order_id`, `order_date`, `region`, `category`, `segment`, `quantity`, `unit_price`, `discount`, `sales`, `profit`.
Practice ke liye dataset mein 25 missing `unit_price`, 15 missing `region`, 8 duplicate rows aur kuch sales outliers jaan-boojhkar shamil kiye gaye.

## 5. Methodology

### 5.1 Data Cleaning
| Problem | Solution |
|---|---|
| 8 duplicate rows | `drop_duplicates()` |
| Missing `region` (categorical) | Mode se fill |
| Missing `unit_price` (numeric) | Median se fill (outliers se kam affect hota hai) |
| Sales outliers (12 found) | IQR method se detect, capping se handle |
| Date column | `datetime` mein convert, month / weekday / profit margin features banaye |

### 5.2 Univariate Analysis
Histogram aur KDE se `sales`, `profit` aur `unit_price` ki distribution dekhi. Sales right-skewed nikli (kam orders bahut bade value ke). Count plots se region, category aur segment ka distribution samjha.

### 5.3 Bivariate Analysis
Category-wise sales/profit bar plots, region-wise box plots, sales vs profit scatter plot, aur monthly sales line plot banaye gaye.

### 5.4 Multivariate Analysis
Correlation heatmap, pair plot aur region x category pivot heatmap se multiple variables ka relation dekha.

## 6. Results and Insights
1. **Electronics** sabse zyada sales wali category hai.
2. **North** region total sales mein sabse aage hai.
3. **March** sabse best performing month raha.
4. **Profit** sabse zyada **sales** se correlated hai.
5. Sales mein 12 outliers mile jo IQR method se cap kiye gaye; capping ke baad max sales 136,037 se ghat kar 24,100 ho gayi.
6. Average profit margin lagbhag **15.6%** hai.

*(Note: numbers notebook ke `seed=42` par based hain; apna dataset use karne par values badal jayengi.)*

## 7. Challenges Faced and Solutions
| Challenge | Solution |
|---|---|
| Outliers ki wajah se plots distort ho rahe the | IQR se detect karke capping ki |
| Missing values ke liye sahi method choose karna | Numeric ke liye median, categorical ke liye mode |
| Bahut saare plots mein clarity | Titles, labels aur dashboard layout use kiya |

## 8. Learning Outcomes
- EDA ka complete workflow samajh aaya.
- Matplotlib aur Seaborn se alag-alag charts banana seekha.
- Outliers aur missing data handle karna seekha.
- Correlation, pivot tables aur dashboard banana seekha.
- Data se business insights likhna seekha.

## 9. Conclusion
Week 3 mein ek raw dataset ko clean karke poora EDA kiya gaya aur clear insights nikale. Ye cleaned data aur EDA ka experience aage Week 4 (Introduction to Machine Learning) mein kaam aayega.

## 10. Next Week Plan (Week 4)
- Machine Learning basics aur train/test split
- Scikit-learn introduction
- Simple Linear Regression aur model evaluation

## 11. References
- Pandas documentation: https://pandas.pydata.org/docs/
- Matplotlib documentation: https://matplotlib.org/stable/
- Seaborn documentation: https://seaborn.pydata.org/
