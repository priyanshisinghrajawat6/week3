# Week 3: Data Visualization & Exploratory Data Analysis (EDA)

**Internship:** Data Science Internship, Next Gen Software Hub Pvt. Ltd.
**Week:** 3 of 6
**Topic:** Matplotlib, Seaborn, data cleaning, univariate / bivariate / multivariate analysis, outlier detection, correlation

## Objective
Raw dataset ko clean karna, visualizations ke through explore karna, aur data se business insights nikalna.

## Files in this folder
| File | Description |
|---|---|
| `Week3_Visualization_EDA.ipynb` | Main notebook (code + explanations) |
| `Week3_Assignment.md` | Practice assignment (questions) |
| `Week3_Project_Report.md` | Week 3 project report |
| `README_Week3.md` | This file |

## Dataset
Retail sales dataset (500 orders) jo notebook ke andar hi code se generate hota hai (`np.random.seed(42)`), isliye internet ya alag CSV ki zaroorat nahi.
Columns: `order_id, order_date, region, category, segment, quantity, unit_price, discount, sales, profit`.
Dataset mein jaan-boojhkar missing values, duplicates aur outliers daale gaye hain.

## What is covered
1. Libraries import aur dataset load
2. First look: `shape`, `info()`, `describe()`, missing values, duplicates
3. Data cleaning: duplicates, missing values (mode / median), feature engineering (month, weekday, profit margin)
4. Univariate analysis: histogram, KDE, count plot, box plot
5. Outlier detection: IQR method aur capping
6. Bivariate analysis: bar plot, box plot, scatter plot, line plot (time trend)
7. Multivariate analysis: correlation heatmap, pair plot, pivot table heatmap
8. Multi-plot dashboard
9. Key insights aur conclusion

## How to run
```bash
pip install numpy pandas matplotlib seaborn jupyter
jupyter notebook Week3_Visualization_EDA.ipynb
```
Phir **Kernel -> Restart & Run All** karein.

## Key insights (from the notebook)
- Highest sales category: **Electronics**
- Highest sales region: **North**
- Best month: **March**
- Profit sabse zyada **sales** se correlated hai
- 12 outliers sales mein mile, IQR method se cap kiye gaye
- Average profit margin: **~15.6%**

## Skills learned
Matplotlib / Seaborn plots, EDA workflow, handling missing data and outliers, correlation analysis, pivot tables, storytelling with data.

## Next week
**Week 4:** Introduction to Machine Learning (train/test split, scikit-learn basics, linear regression).
